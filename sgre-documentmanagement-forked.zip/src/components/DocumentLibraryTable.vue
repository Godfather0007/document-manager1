<template>
  <div class="DocumentManagement DocumentLibraryTable">
    <div class="table-responsive">
      <table class="table table-sm">
        <thead>
          <tr>
            <th>&nbsp;</th>
            <th scope="col">Title</th>
            <th scope="col">Document Type</th>
            <th scope="col">Language</th>
            <th scope="col">Version</th>
            <th scope="col">Year</th>
            <th scope="col">Month</th>
            <th scope="col">Modified</th>
            <th scope="col">Created</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>&mdash;</td>
            <td>HSE Document Title</td>
            <td>Safety Alert</td>
            <td>English</td>
            <td>1.0</td>
            <td>2020</td>
            <td>Jan</td>
            <td>June 20, 2020</td>
            <td>Jan 1, 2020</td>
          </tr>
          <tr>
            <td>&mdash;</td>
            <td>HSE Document Title</td>
            <td>Safety Alert</td>
            <td>Spainish</td>
            <td>1.0</td>
            <td>2020</td>
            <td>Jan</td>
            <td>June 20, 2020</td>
            <td>Jan 1, 2020</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  name: "DocumentLibraryTable"
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
