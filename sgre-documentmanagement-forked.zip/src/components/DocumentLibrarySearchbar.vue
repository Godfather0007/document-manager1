<template>
  <div class="DocumentManagement DocumentLibrarySearchbar">
    <div class="bg-light border border-secondary p-2">Document Library Searchbar goes here</div>
  </div>
</template>

<script>
export default {
  name: "DocumentLibrarySearchbar"
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
