<template>
  <div class="DocumentManagement DocumentLibraryFilters">
    <div class="bg-white border border-secondary p-3">
      <form class="form">
        <div class="form-group">
          <label>Windfarm</label>
          <select class="form-control">
            <option>Windfarm 1</option>
            <option>Windfarm 2</option>
            <option>Windfarm 3</option>
          </select>
        </div>
        <div class="form-group">
          <label>Application Group</label>
          <select class="form-control">
            <option>Application 1</option>
            <option>Application 2</option>
            <option>Application 3</option>
          </select>
        </div>
        <div class="form-group">
          <label>Document Type</label>
          <select class="form-control">
            <option>Type 1</option>
            <option>Type 2</option>
            <option>Type 3</option>
          </select>
        </div>
        <div class="form-group">
          <label>Language</label>
          <select class="form-control">
            <option>Language 1</option>
            <option>Language 2</option>
            <option>Language 3</option>
          </select>
        </div>
        <div class="row">
          <div class="col-sm-6">
            <div class="form-group">
              <label>Date From</label>
              <input class="form-control" type="date">
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group">
              <label>Date To</label>
              <input class="form-control" type="date">
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  name: "DocumentLibraryFilters"
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
